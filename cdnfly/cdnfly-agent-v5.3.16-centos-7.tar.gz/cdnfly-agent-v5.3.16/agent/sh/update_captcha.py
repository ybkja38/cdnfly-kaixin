# -*- coding: utf-8 -*-

import random
from PIL import Image
import os

def add_transparent_pixel_randomly(image_path, output_path):
    img = Image.open(image_path).convert("RGBA")  # 转换为具有 alpha 通道的 RGBA 格式，保留透明背景

    width, height = img.size
    random_x = random.randint(0, width - 1)
    random_y = random.randint(0, height - 1)

    while img.getpixel((random_x, random_y))[3] == 0:  # 如果随机位置的像素已经是透明的，则重新选择随机位置
        random_x = random.randint(0, width - 1)
        random_y = random.randint(0, height - 1)

    img.putpixel((random_x, random_y), (0, 0, 0, 0))  # 在随机位置添加一个透明像素
    img.save(output_path)

print "start update captcha..."
for f in os.listdir("/opt/cdnfly/nginx/conf/captcha/"):
    input_png = "/opt/cdnfly/nginx/conf/captcha-origin/" + f
    output_png = "/opt/cdnfly/nginx/conf/captcha/" + f
    
    add_transparent_pixel_randomly(input_png, output_png)

print "update captcha done."